package org.A1;


import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class InsertionSort{
    final static double REDUCTION = 0.01;
    public static <T extends Comparable<? super T>> int sort(List<T> list) {
        int counter = 0; // Initialize the counter

        for (int i = 1; i < list.size(); i++) {
            T key = list.get(i);
            int j = i - 1;

            counter++; // Count the operation of setting key

            // Count the comparison and shifting operations
            while (j >= 0 && list.get(j).compareTo(key) > 0) {
                counter++; // Count the comparison operation
                list.set(j + 1, list.get(j)); // Shift operation
                counter++; // Count the shifting operation
                j--;
            }

            list.set(j + 1, key);
            counter++; // Count the insertion operation
            if(list instanceof ArrayList<T>){
                RacingPanel.setXVelocityAl7((int) (counter ));//------------
            } else if (list instanceof LinkedList<T>) {
                RacingPanel.setXVelocityAl8((int) (counter ));//------------
            }
        }

        return counter; // Return the number of operations
    }
    public Runnable InsertionSortAry(){
        ArrayList<University> universityArrayList = new ArrayList<University>();
       DataInput.readFile(universityArrayList);

        Collections.shuffle(universityArrayList);

        InsertionSort.sort(universityArrayList);


        return null;
    }

    public Runnable InsertionSortLink(){
        LinkedList<University> universityLinkedList = new LinkedList<University>();
        DataInput.readFile(universityLinkedList);

        Collections.shuffle(universityLinkedList);

        InsertionSort.sort(universityLinkedList);


        return null;
    }
}
