/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.A1;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import javax.swing.JFrame;

/**
 *
 * @author c3rea
 */
public class Calculations {
    
    
    public static void CalcValues(String filename) {
        ArrayList<Integer> intArray = new ArrayList<>();
       

       DataInput.readOperation(filename, intArray);
        
        
        double median= getMedian(intArray);
        System.out.println("Median: " + median);
        
        double mean = getMean(intArray);
        System.out.println("Mean: " +mean);
        
        System.out.println("Best: " +Collections.min(intArray));
        System.out.println("Worst: " +Collections.max(intArray));   
    }
    
    public static double getMedian(List<Integer> list) {
        int size = list.size();
        Collections.sort(list);
        // Check if the size of the list is even
        if (size % 2 == 0) {
            // Calculate the median for even-sized lists
            int mid = size / 2;
            return (double) (list.get(mid) + list.get(mid - 1)) / 2;
        }

        // Calculate the median for odd-sized lists
        return list.get(size / 2);
    }
    public static double getMean(List<Integer> list){
        int sum = 0;
        for (int num : list) {
            sum += num;
        }


        // Calculate the average of elements
        return (double)sum / list.size();
    }
    
    
 
    
    
    public static<T> void worstComplexityOperation (int runs,ArrayList<T> uniArray, LinkedList<T> uniLinked) throws InterruptedException {
        // check if empty
         if (uniArray.isEmpty() || uniLinked.isEmpty()) {
             System.out.println("One or both lists are empty.");
             return;
         }

         //  ensure type safety
         if (!(uniArray.get(0) instanceof University) || !(uniLinked.get(0) instanceof University)) {
             throw new ClassCastException("Both lists must contain elements of type University.");
         }

             ArrayList<University> uniArrayList = (ArrayList<University>) uniArray;
             LinkedList<University> uniLinkedList = (LinkedList<University>) uniLinked;
             
             ArrayList<University> tempuniarrayL = new ArrayList<University>() ;
             LinkedList<University>  tempuniLinkL = new LinkedList<University>() ;
             
            ArrayList<Integer> worstBubbleA = new ArrayList<Integer>();
            ArrayList<Integer> worstBubbleLL = new ArrayList<Integer>();

            ArrayList<Integer> worstBuiltA = new ArrayList<Integer>();
            ArrayList<Integer> worstBuiltLL = new ArrayList<Integer>();


            ArrayList<Integer> worstMergeA = new ArrayList<Integer>();
            ArrayList<Integer> worstMergeLL = new ArrayList<Integer>();

            ArrayList<Integer>worstInsertA = new ArrayList<Integer>();
            ArrayList<Integer> worstInsertLL = new ArrayList<Integer>();
            ArrayList<Integer> Xval = new ArrayList<Integer>();

            int max = 1600;
             
            //runs it for runs times for each size and adds the worst value out the number of runs for each size to an array
            for(int i = 100;i <= max;i += 100){
                 tempuniarrayL.clear();
                 tempuniLinkL.clear();
                    for(int j = 0;j < i; j++){ //create list 0 to 100

                     tempuniarrayL.add(uniArrayList.get(j));
                     tempuniLinkL.add(uniLinkedList.get(j));
                    }
                 Xval.add(i);
                 
                 DataOutput.NumOFOperationWorst(runs,tempuniarrayL,tempuniLinkL,worstBubbleA,worstBubbleLL,worstBuiltA,worstBuiltLL,worstMergeA,worstMergeLL,worstInsertA,worstInsertLL);
             
            }
            
            GraphingUtils.createGraph(Xval, worstBubbleA, worstBubbleLL, 
                                      worstBuiltA, worstBuiltLL, 
                                      worstMergeA, worstMergeLL, 
                                      worstInsertA, worstInsertLL);

    }




   public class FileUtils {

    public static void writeListToFile(List<Integer> data, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Integer value : data) {
                writer.write(value.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
    
    
}


