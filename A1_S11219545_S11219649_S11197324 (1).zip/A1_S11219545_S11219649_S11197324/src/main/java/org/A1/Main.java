package org.A1;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Scanner;
//
public class Main {
    public static void main(String[] args) throws IOException, InterruptedException {
        ArrayList<University> universityArrayList = new ArrayList<>();
        LinkedList<University> universityLinkedList = new LinkedList<>();
        
        DataInput.readFile(universityArrayList);
        DataInput.readFile(universityLinkedList);
       
        boolean cont=true;
        String choice;
        
        Scanner scanner =new Scanner(System.in);
        while(cont){
            
            System.out.println("\nPlease choose one of the following options: \n");
        
            System.out.println("Type '1' to race the algorithms." );
            System.out.println("Type '2' to collect data to analyze the mean, median, best and worst." );
            System.out.println("Type '3' to analyze the worst time complexity.");
            System.out.println("Type '4' to sort the list and display results.");
            System.out.println("'Q' or 'q'- to quit the program");
            choice = scanner.nextLine();
            int size;
            switch(choice){                  
                case "1"://race algorithms
                    System.out.println("Beginning simulation: ");
                      RacingPanel.resetStaticVariables();
                      RacingFrame racing = new RacingFrame();
                    break;
                case "2":
                    System.out.println("Enter the number of times you'd like to run the algorithms:(>=30 is recommended)");
                    size =scanner.nextInt();
                    System.out.println("Beginning calculation: ");
                    
                    //runn algorithm and out number of operation depending on size
                    DataOutput.NumOFOperation(size,universityArrayList,universityLinkedList);
                  
                    //Find mean,median,best and worst for each algorithm.
                    String[] algorithms = {"BubbleSort with ArrayList", "BubbleSort with LinkedList", "BuiltInSort with ArrayList", 
                        "BuiltInSort with LinkedList", "MergeSort with ArrayList", "MergeSort with LinkedList", "InsertionSort with ArrayList",
                        "InsertionSort with LinkedList"};
                        for (String algo : algorithms) {
                            System.out.println("\nUsing  " + algo + ": ");
                            Calculations.CalcValues(algo + ".txt");
                        }          
                    break;
                case "3"://plot worst complexity graph
                    System.out.println("Enter the number of times you'd like to run the algorithms.(larger numbers will take more time)");
                    int runs =scanner.nextInt();
                    System.out.println("Beginning calculation: ");
                   Calculations.worstComplexityOperation(runs,universityArrayList,universityLinkedList);
                   break;
                case "4"://Select data stucture and sorting algorithm
                    Result.sortList(universityArrayList, universityLinkedList);
                   break; 
                case "Q":
                    cont=false;
                    break;
                case "q":
                     cont=false;
                    break;  
                    
                default:System.out.println("Not a valid input\n");
            }
        }
    }   
}
