package org.A1;


import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class BubbleSort {
    final static double REDUCTION = 0.01;
    public static <T extends Comparable<? super T>> int sort(List<T> list) {
        boolean swapped;
        int counter = 0; // Initialize the counter

        for (int i = 0; i < list.size() - 1; i++) {
            swapped = false;
            for (int j = 0; j < list.size() - i - 1; j++) {
                counter++; // Count the comparison operation
                if (list.get(j).compareTo(list.get(j + 1)) > 0) {
                    // Swap operation
                    T temp = list.get(j);
                    list.set(j, list.get(j + 1));
                    list.set(j + 1, temp);
                    swapped = true;
                    counter += 3; // Count the swap operation (3 steps: get, set, set)
                    if(list instanceof ArrayList<T>){
                        RacingPanel.setXVelocityAl1((int) (counter ));//------------
                    } else if (list instanceof LinkedList<T>) {
                        RacingPanel.setXVelocityAl2((int) (counter ));//------------
                    }

                }

            }
            if (!swapped) break; // No swaps mean the list is already sorted
        }

        return counter; // Return the number of operations
    }

    public Runnable BubbleSortAry(){
        ArrayList<University> universityArrayList = new ArrayList<University>();
        DataInput.readFile(universityArrayList);

        Collections.shuffle(universityArrayList);

        BubbleSort.sort(universityArrayList);




        return null;
    }

    public Runnable BubbleSortLink(){
        LinkedList<University> universityLinkedList = new LinkedList<University>();
        DataInput.readFile(universityLinkedList);

        Collections.shuffle(universityLinkedList);

        BubbleSort.sort(universityLinkedList);




        return null;
    }




}
