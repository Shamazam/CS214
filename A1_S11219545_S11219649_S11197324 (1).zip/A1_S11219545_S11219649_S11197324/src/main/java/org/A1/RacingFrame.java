package org.A1;

import javax.swing.*;

public class RacingFrame extends JFrame {
    //Declares an instance of RacingPanel
    RacingPanel panel;

    public RacingFrame(){
        //Initalizes panel as a new RacingPanel with the RacingFrame Constructor
        panel = new RacingPanel();

//        //Allows the main loop to run when the JFrame is closed
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        this.add(panel);//Adds the panel to the JFrame
        this.pack();//packs the panel to fit correctly within the JFrame

        //Allows the JFrame to appear in the  middle of the screeen
        setLocationRelativeTo(null);

        //Allows the JFrame to be Visible
        setVisible(true);
    }
}
