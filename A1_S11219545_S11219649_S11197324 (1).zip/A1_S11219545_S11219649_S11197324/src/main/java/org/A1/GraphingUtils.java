package org.A1;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.title.LegendTitle;
import org.jfree.chart.ui.RectangleEdge;
import java.awt.BasicStroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GraphingUtils {

    private static JFrame previousFrame = null; // To keep track of the previous frame
    private static Timer timer; // Timer for animation

    public static void createGraph(final ArrayList<Integer> xValues, final ArrayList<Integer> bubbleSortA, final ArrayList<Integer> bubbleSortLL,
                                   final ArrayList<Integer> builtInA, final ArrayList<Integer> builtInLL,
                                   final ArrayList<Integer> mergeSortA, final ArrayList<Integer> mergeSortLL,
                                   final ArrayList<Integer> insertSortA, final ArrayList<Integer> insertSortLL) {

        // Dispose of the previous frame if it exists
        if (previousFrame != null) {
            previousFrame.dispose();
        }

        // Create the series
        final XYSeries seriesBubbleSortA = new XYSeries("Bubble Sort ArrayList");
        final XYSeries seriesBubbleSortLL = new XYSeries("Bubble Sort LinkedList");
        final XYSeries seriesBuiltInA = new XYSeries("Built-in Sort ArrayList");
        final XYSeries seriesBuiltInLL = new XYSeries("Built-in Sort LinkedList");
        final XYSeries seriesMergeSortA = new XYSeries("Merge Sort ArrayList");
        final XYSeries seriesMergeSortLL = new XYSeries("Merge Sort LinkedList");
        final XYSeries seriesInsertSortA = new XYSeries("Insertion Sort ArrayList");
        final XYSeries seriesInsertSortLL = new XYSeries("Insertion Sort LinkedList");

        // Create the dataset
        final XYSeriesCollection dataset = new XYSeriesCollection();
        dataset.addSeries(seriesBubbleSortA);
        dataset.addSeries(seriesBubbleSortLL);
        dataset.addSeries(seriesBuiltInA);
        dataset.addSeries(seriesBuiltInLL);
        dataset.addSeries(seriesMergeSortA);
        dataset.addSeries(seriesMergeSortLL);
        dataset.addSeries(seriesInsertSortA);
        dataset.addSeries(seriesInsertSortLL);

        // Create the chart
        final JFreeChart chart = ChartFactory.createXYLineChart(
                "WORST COMPLEXITY OF ALGORITHMS",
                "Number of Elements",
                "Number of Operations",
                dataset,
                PlotOrientation.VERTICAL,
                true, // Include legend
                true, // Include tooltips
                false // Include URL links
        );

        // Customize the chart
        final XYPlot plot = chart.getXYPlot();
        final NumberAxis yAxis = (NumberAxis) plot.getRangeAxis();
        yAxis.setTickUnit(new org.jfree.chart.axis.NumberTickUnit(450000));

        final XYLineAndShapeRenderer renderer = new XYLineAndShapeRenderer();
        for (int i = 0; i < 8; i++) {
            renderer.setSeriesStroke(i, new BasicStroke(2.0f)); // Adjust line thickness
        }
        plot.setRenderer(renderer);

        final LegendTitle legend = chart.getLegend();
        legend.setPosition(RectangleEdge.TOP);
        legend.setItemFont(new Font("SansSerif", Font.BOLD, 12)); // Adjust font size

        // Create and display the new frame
        previousFrame = new JFrame("WORST COMPLEXITY OF ALGORITHMS");
        previousFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        previousFrame.add(new ChartPanel(chart));
        previousFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        previousFrame.setVisible(true);

        // Timer to animate the chart
        timer = new Timer(1000, new ActionListener() { // Update every second
            private int index = 0;

            @Override
            public void actionPerformed(ActionEvent e) {
                if (index < xValues.size()) {
                    seriesBubbleSortA.add(xValues.get(index), bubbleSortA.get(index));
                    seriesBubbleSortLL.add(xValues.get(index), bubbleSortLL.get(index));
                    seriesBuiltInA.add(xValues.get(index), builtInA.get(index));
                    seriesBuiltInLL.add(xValues.get(index), builtInLL.get(index));
                    seriesMergeSortA.add(xValues.get(index), mergeSortA.get(index));
                    seriesMergeSortLL.add(xValues.get(index), mergeSortLL.get(index));
                    seriesInsertSortA.add(xValues.get(index), insertSortA.get(index));
                    seriesInsertSortLL.add(xValues.get(index), insertSortLL.get(index));
                    index++;
                } else {
                    timer.stop(); // Stop the timer once all data points have been added
                }
            }
        });

        timer.start(); // Start the animation
    }
}
