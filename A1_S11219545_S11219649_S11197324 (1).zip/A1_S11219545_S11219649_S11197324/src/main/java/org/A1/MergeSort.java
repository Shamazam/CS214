package org.A1;


import java.util.*;

import static org.A1.University.compareBy;

public class MergeSort {
    private static int counter; // Counter for tracking operations

    public MergeSort() {
        // No need to initialize counter in the constructor
    }

    public static <T extends Comparable<? super T>> int sort(List<T> list) {
        // Reset the counter at the beginning of each sort operation
        counter = 0;

        if (list.size() < 2) {
            return counter;
        }

        int mid = list.size() / 2;

        // Create separate copies of the sublists
        List<T> left = new ArrayList<>(list.subList(0, mid));
        List<T> right = new ArrayList<>(list.subList(mid, list.size()));

        sort(left);  // Recursively sort the left sublist
        sort(right); // Recursively sort the right sublist

        counter += merge(list, left, right); // Merge the sorted sublists

        if (list instanceof ArrayList<T>) {
            RacingPanel.setXVelocityAl5(counter); //------------
        } else if (list instanceof LinkedList<T>) {
            RacingPanel.setXVelocityAl6(counter); //------------
        }

        return counter; // Return the number of operations
    }

    private static <T extends Comparable<? super T>> int merge(List<T> list, List<T> left, List<T> right) {
        int i = 0, j = 0, k = 0;

        // Merge the left and right lists into the original list
        while (i < left.size() && j < right.size()) {
            counter++; // Count the comparison

            if (left.get(i).compareTo(right.get(j)) <= 0) {
                list.set(k++, left.get(i++));
                counter++; // Count the assignment
            } else {
                list.set(k++, right.get(j++));
                counter++; // Count the assignment
            }
        }

        // Add any remaining elements from the left list
        while (i < left.size()) {
            list.set(k++, left.get(i++));
            counter++; // Count the assignment
        }

        // Add any remaining elements from the right list
        while (j < right.size()) {
            list.set(k++, right.get(j++));
            counter++; // Count the assignment
        }


        return counter;
    }



    public Runnable MergeSortAry(){
        ArrayList<University> universityArrayList = new ArrayList<University>();
      DataInput.readFile(universityArrayList);

        Collections.shuffle(universityArrayList);

        MergeSort.sort(universityArrayList);


        return null;
    }

    public Runnable MergeSortLink(){
        LinkedList<University> universityLinkedList = new LinkedList<University>();
        DataInput.readFile(universityLinkedList);

        Collections.shuffle(universityLinkedList);

        MergeSort.sort(universityLinkedList);


        return null;
    }
}

