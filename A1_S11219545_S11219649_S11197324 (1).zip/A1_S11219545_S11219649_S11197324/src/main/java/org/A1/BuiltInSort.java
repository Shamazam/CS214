package org.A1;



import java.util.*;

public class BuiltInSort {
    private static int counter; // Counter to track the number of operations



    public static <T extends Comparable<T>> int sort(List<T> list) {
        // Reset the counter at the start of the sort method
        counter = 0;

        // Custom comparator that increments the counter for each comparison
        Comparator<T> comparator = (o1, o2) -> {
            counter++; // Increment the counter for each comparison

            if (list instanceof ArrayList<T>) {
                RacingPanel.setXVelocityAl3(counter); //------------
            } else if (list instanceof LinkedList<T>) {
                RacingPanel.setXVelocityAl4(counter); //------------
            }

            return o1.compareTo(o2);
        };

        // Perform the sort using the custom comparator
        Collections.sort(list, comparator);

        return counter; // Return the number of operations
    }

    public int getCounter() {
        return counter;
    }

    public Runnable BuiltinSortAry(){
        ArrayList<University> universityArrayList = new ArrayList<University>();
        DataInput.readFile(universityArrayList);

        Collections.shuffle(universityArrayList);

        BuiltInSort.sort(universityArrayList);


        return null;
    }

    public Runnable BuiltinSortLink(){
        LinkedList<University> universityLinkedList = new LinkedList<University>();
        DataInput.readFile(universityLinkedList);

        Collections.shuffle(universityLinkedList);

        BuiltInSort.sort(universityLinkedList);


        return null;
    }
}
