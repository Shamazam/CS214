package org.A1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RacingPanel extends JPanel implements ActionListener {

    final static double REDUCTION = 0.01;
    Timer timer;

    // Initialize velocities and positions
    static int xVelocityAl1 = 0;
    static int xVelocityAl2 = 0;
    static int xVelocityAl3 = 0;
    static int xVelocityAl4 = 0;
    static int xVelocityAl5 = 0;
    static int xVelocityAl6 = 0;
    static int xVelocityAl7 = 0;
    static int xVelocityAl8 = 0;

    static int x = 50;
    static int x2 = 50;
    static int x3 = 50;
    static int x4 = 50;
    static int x5 = 50;
    static int x6 = 50;
    static int x7 = 50;
    static int x8 = 50;

    static int y = 150; // Adjusted y to give space for the button

    JButton button;
    JLabel winnerLabel;

    // Threads for sorting algorithms
    Thread InsertionsortThread = new Thread(new InsertionSort().InsertionSortAry());
    Thread InsertionsortThread2 = new Thread(new InsertionSort().InsertionSortLink());
    Thread BubblesortThread = new Thread(new BubbleSort().BubbleSortAry());
    Thread BubblesortThread2 = new Thread(new BubbleSort().BubbleSortLink());
    Thread BuiltinsortThread = new Thread(new BuiltInSort().BuiltinSortAry());
    Thread BuiltinsortThread2 = new Thread(new BuiltInSort().BuiltinSortLink());
    Thread MergesortThread = new Thread(new MergeSort().MergeSortAry());
    Thread MergesortThread1 = new Thread(new MergeSort().MergeSortLink());

    RacingPanel(){
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int screenWidth = (int) screenSize.getWidth();
        int screenHeight = (int) screenSize.getHeight();

        this.setPreferredSize(new Dimension(screenWidth, screenHeight));

        timer = new Timer(16, this);

        button = new JButton();
        button.setBounds((screenWidth - 100) / 2, 20, 100, 50); // Centered at the top
        button.addActionListener(this);
        button.setText("Start Race!");
        button.setFocusable(true);

        winnerLabel = new JLabel(" ");
        winnerLabel.setBounds(100, 70, screenWidth - 200, 30); // Adjusted to fit in available space
        winnerLabel.setFont(new Font("Serif", Font.BOLD, 20));
        winnerLabel.setForeground(Color.RED);

        this.setLayout(null); // Set layout to null to use absolute positioning
        this.add(button);
        this.add(winnerLabel);
    }

    @Override
    public void paint(Graphics g){
        super.paint(g);
        Graphics2D g2D = (Graphics2D) g;

        g2D.setColor(Color.BLACK);
        int finishLineX = getWidth() - 60;
        g2D.drawLine(finishLineX, 0, finishLineX, getHeight());

        g2D.setColor(Color.RED);
        g2D.fillRect(x, y, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("BubbleSort (ArrayList)", x + 10, y + 25);

        g2D.setColor(Color.BLUE);
        g2D.fillRect(x2, y + 50, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("BubbleSort (LinkedList)", x2 + 10, y + 75);

        g2D.setColor(Color.GREEN);
        g2D.fillRect(x3, y + 100, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("BuiltInSort (ArrayList)", x3 + 10, y + 125);

        g2D.setColor(Color.ORANGE);
        g2D.fillRect(x4, y + 150, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("BuiltInSort (LinkedList)", x4 + 10, y + 175);

        g2D.setColor(Color.MAGENTA);
        g2D.fillRect(x5, y + 200, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("MergeSort (ArrayList)", x5 + 10, y + 225);

        g2D.setColor(Color.CYAN);
        g2D.fillRect(x6, y + 250, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("MergeSort (LinkedList)", x6 + 10, y + 275);

        g2D.setColor(Color.GRAY);
        g2D.fillRect(x7, y + 300, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("InsertionSort (ArrayList)", x7 + 10, y + 325);

        g2D.setColor(Color.PINK);
        g2D.fillRect(x8, y + 350, 150, 40);
        g2D.setColor(Color.BLACK);
        g2D.drawString("InsertionSort (LinkedList)", x8 + 10, y + 375);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == button) {
            BubblesortThread.start();
            BubblesortThread2.start();
            BuiltinsortThread.start();
            BuiltinsortThread2.start();
            MergesortThread.start();
            MergesortThread1.start();
            InsertionsortThread.start();
            InsertionsortThread2.start();

            timer.start();
            button.setEnabled(false);
        } else if (e.getSource() == timer) {
            x += xVelocityAl1;
            x2 += xVelocityAl2;
            x3 += xVelocityAl3;
            x4 += xVelocityAl4;
            x5 += xVelocityAl5;
            x6 += xVelocityAl6;
            x7 += xVelocityAl7;
            x8 += xVelocityAl8;

            if (finishCondition()) {
                timer.stop();
                button.setEnabled(true);
                showWinnerMessage();
                return;
            }

            repaint();
        }
    }

    private void showWinnerMessage() {
        String winner = "No winner yet";
        if (x >= getWidth() - 150) {
            winner = "BubbleSort (ArrayList) wins!";
        } else if (x2 >= getWidth() - 150) {
            winner = "BubbleSort (LinkedList) wins!";
        } else if (x3 >= getWidth() - 150) {
            winner = "BuiltInSort (ArrayList) wins!";
        } else if (x4 >= getWidth() - 150) {
            winner = "BuiltInSort (LinkedList) wins!";
        } else if (x5 >= getWidth() - 150) {
            winner = "MergeSort (ArrayList) wins!";
        } else if (x6 >= getWidth() - 150) {
            winner = "MergeSort (LinkedList) wins!";
        } else if (x7 >= getWidth() - 150) {
            winner = "InsertionSort (ArrayList) wins!";
        } else if (x8 >= getWidth() - 150) {
            winner = "InsertionSort (LinkedList) wins!";
        }

        winnerLabel.setText(winner);
    }

    public boolean finishCondition() {
        return x >= getWidth() - 150 ||
                x2 >= getWidth() - 150 ||
                x3 >= getWidth() - 150 ||
                x4 >= getWidth() - 150 ||
                x5 >= getWidth() - 150 ||
                x6 >= getWidth() - 150 ||
                x7 >= getWidth() - 150 ||
                x8 >= getWidth() - 150;
    }

    public static void setXVelocityAl1(int operations){
        xVelocityAl1 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl2(int operations){
        xVelocityAl2 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl3(int operations){
        xVelocityAl3 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl4(int operations){
        xVelocityAl4 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl5(int operations){
        xVelocityAl5 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl6(int operations){
        xVelocityAl6 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl7(int operations){
        xVelocityAl7 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    public static void setXVelocityAl8(int operations){
        xVelocityAl8 = Math.max(10, (int) (10000 / (operations * REDUCTION)));
    }
    
    public static void resetStaticVariables() {
        xVelocityAl1 = 0;
        xVelocityAl2 = 0;
        xVelocityAl3 = 0;
        xVelocityAl4 = 0;
        xVelocityAl5 = 0;
        xVelocityAl6 = 0;
        xVelocityAl7 = 0;
        xVelocityAl8 = 0;

        x = 50;
        x2 = 50;
        x3 = 50;
        x4 = 50;
        x5 = 50;
        x6 = 50;
        x7 = 50;
        x8 = 50;

        y = 150; // Adjusted y to give space for the button
    }
}
