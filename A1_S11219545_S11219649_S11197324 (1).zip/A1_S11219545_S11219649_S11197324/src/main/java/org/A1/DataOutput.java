/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.A1;



import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

import static org.A1.University.compareBy;

/**
 *
 * @author c3rea
 */
public class DataOutput {
    
   public static<T> void NumOFOperation(int size, ArrayList<T> uniArray, LinkedList<T> uniLinked) {
       
            // check if empty
         if (uniArray.isEmpty() || uniLinked.isEmpty()) {
             System.out.println("One or both lists are empty.");
             return;
         }

         //  ensure type safety
         if (!(uniArray.get(0) instanceof University) || !(uniLinked.get(0) instanceof University)) {
             throw new ClassCastException("Both lists must contain elements of type University.");
         }

             ArrayList<University> uniArrayList = (ArrayList<University>) uniArray;
             LinkedList<University> uniLinkedList = (LinkedList<University>) uniLinked;

       
        BufferedWriter bubbleWriter1 = null;
        BufferedWriter bubbleWriter2 = null;
        BufferedWriter builtinWriter1 = null;
        BufferedWriter builtinWriter2 = null;
        BufferedWriter mergeWriter1 = null;
        BufferedWriter mergeWriter2 = null;
        BufferedWriter insertWriter1 = null;
        BufferedWriter insertWriter2 = null;

        try {
            // Initialize BufferedWriter objects in append mode
            bubbleWriter1 = new BufferedWriter(new FileWriter("BubbleSort with ArrayList.txt"));
            bubbleWriter2 = new BufferedWriter(new FileWriter("BubbleSort with LinkedList.txt"));
            builtinWriter1 = new BufferedWriter(new FileWriter("BuiltInSort with ArrayList.txt"));
            builtinWriter2 = new BufferedWriter(new FileWriter("BuiltInSort with LinkedList.txt"));
            mergeWriter1 = new BufferedWriter(new FileWriter("MergeSort with ArrayList.txt"));
            mergeWriter2 = new BufferedWriter(new FileWriter("MergeSort with LinkedList.txt"));
            insertWriter1 = new BufferedWriter(new FileWriter("InsertionSort with ArrayList.txt"));
            insertWriter2 = new BufferedWriter(new FileWriter("InsertionSort with LinkedList.txt"));

            int operation;

            for (int i = 0; i < size; i++) {
                // Shuffle lists
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Bubble Sort
                operation = BubbleSort.sort(uniArrayList);
                bubbleWriter1.append(operation + " ");

                operation = BubbleSort.sort(uniLinkedList);
                bubbleWriter2.append(operation + " ");

                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Insertion Sort
                operation = InsertionSort.sort(uniArrayList);
                insertWriter1.append(operation + " ");

                operation = InsertionSort.sort(uniLinkedList);
                insertWriter2.append(operation + " ");

                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Built-In Sort
                operation = BuiltInSort.sort(uniArrayList);
                builtinWriter1.append(operation + " ");

                operation = BuiltInSort.sort(uniLinkedList);
                builtinWriter2.append(operation + " ");

                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Merge Sort
                Comparator<University> compareRank = Comparator.comparingInt(University::getUniversityRank);

                operation = MergeSort.sort(uniArrayList);
                mergeWriter1.append(operation + " ");

                operation = MergeSort.sort(uniLinkedList);
                mergeWriter2.append(operation + " ");
                
                // Add a newline 
                bubbleWriter1.newLine();
                bubbleWriter2.newLine();
                insertWriter1.newLine();
                insertWriter2.newLine();
                builtinWriter1.newLine();
                builtinWriter2.newLine();
                mergeWriter1.newLine();
                mergeWriter2.newLine();
            }
        } catch (IOException e) {
            // Handle IOException
            System.err.println("An I/O error occurred: " + e.getMessage());
        } finally {
            // Ensure that all resources are closed
            try {
                if (bubbleWriter1 != null) bubbleWriter1.close();
                if (bubbleWriter2 != null) bubbleWriter2.close();
                if (builtinWriter1 != null) builtinWriter1.close();
                if (builtinWriter2 != null) builtinWriter2.close();
                if (mergeWriter1 != null) mergeWriter1.close();
                if (mergeWriter2 != null) mergeWriter2.close();
                if (insertWriter1 != null) insertWriter1.close();
                if (insertWriter2 != null) insertWriter2.close();
            } catch (IOException e) {
                // Handle IOException from closing the BufferedWriters
                System.err.println("An error occurred while closing the BufferedWriters: " + e.getMessage());
            }
        }
    }

   public static<T> void NumOFOperationWorst(int size, ArrayList<T> uniArray, LinkedList<T> uniLinked,ArrayList<Integer> worstBubbleA ,ArrayList<Integer> worstBubbleLL,ArrayList<Integer> worstBuiltA,ArrayList<Integer> worstBuiltLL,   ArrayList<Integer> worstMergeA , ArrayList<Integer> worstMergeLL ,   ArrayList<Integer>worstInsertA ,   ArrayList<Integer>worstInsertLL) {
       
            // check if empty
         if (uniArray.isEmpty() || uniLinked.isEmpty()) {
             System.out.println("One or both lists are empty.");
             return;
         }

         //  ensure type safety
         if (!(uniArray.get(0) instanceof University) || !(uniLinked.get(0) instanceof University)) {
             throw new ClassCastException("Both lists must contain elements of type University.");
         }

        ArrayList<University> uniArrayList = (ArrayList<University>) uniArray;
        LinkedList<University> uniLinkedList = (LinkedList<University>) uniLinked;
            
        ArrayList<Integer> tempvalBubbleA = new ArrayList<Integer>();
        ArrayList<Integer> tempvalBubbleLL = new ArrayList<Integer>();
         
        ArrayList<Integer> tempvalBuiltA = new ArrayList<Integer>();
        ArrayList<Integer> tempvalBuiltLL = new ArrayList<Integer>();
          
          
        ArrayList<Integer> tempvalMergeA = new ArrayList<Integer>();
        ArrayList<Integer> tempvalMergeLL = new ArrayList<Integer>();
        
        ArrayList<Integer> tempvalInsertA = new ArrayList<Integer>();
        ArrayList<Integer> tempvalInsertLL = new ArrayList<Integer>();



       int operation;
            
       for (int i = 0; i < size; i++) {
                // Shuffle lists
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Bubble Sort
                operation = BubbleSort.sort(uniArrayList);
                tempvalBubbleA.add(operation);

                operation = BubbleSort.sort(uniLinkedList);
                tempvalBubbleLL.add(operation);

                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Insertion Sort
                operation = InsertionSort.sort(uniArrayList);
                tempvalInsertA.add(operation);

                operation = InsertionSort.sort(uniLinkedList);
                tempvalInsertLL.add(operation);

                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Built-In Sort
                operation = BuiltInSort.sort(uniArrayList);
                tempvalBuiltA.add(operation);

                operation = BuiltInSort.sort(uniLinkedList);
                tempvalBuiltLL.add(operation);
                
                
                // Shuffle lists again for next sorting
                Collections.shuffle(uniArrayList);
                Collections.shuffle(uniLinkedList);

                // Merge Sort
                operation = MergeSort.sort(uniArrayList);
                tempvalMergeA.add(operation);

               operation = MergeSort.sort(uniLinkedList);
               tempvalMergeLL.add(operation);         
       }
       
              worstBubbleA.add(Collections.max(tempvalBubbleA));
              worstBubbleLL.add(Collections.max(tempvalBubbleLL));
              
              worstBuiltA.add(Collections.max(tempvalBuiltA));
              worstBuiltLL.add(Collections.max(tempvalBuiltLL));
              
              
              worstMergeA.add(Collections.max(tempvalMergeA));
              worstMergeLL.add(Collections.max(tempvalMergeLL));
              
              worstInsertA.add(Collections.max(tempvalInsertA));
              worstInsertLL.add(Collections.max(tempvalInsertLL));    
    }

}
