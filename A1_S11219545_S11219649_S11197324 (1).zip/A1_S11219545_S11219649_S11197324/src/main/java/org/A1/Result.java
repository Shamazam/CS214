/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.A1;

import java.util.*;

import static org.A1.University.compareBy;

/**
 *
 * @author c3rea
 */
public class Result {
     public static  <T> void printList(List<T> list) throws InterruptedException {
       
        for (T item : list) {
            System.out.println(item.toString());
            Thread.sleep(5);
        }
    }
     
      public static<T> void sortList(ArrayList<T> uniArray, LinkedList<T> uniLinked) throws InterruptedException {
       
              // check if empty
         if (uniArray.isEmpty() || uniLinked.isEmpty()) {
             System.out.println("One or both lists are empty.");
             return;
         }

         //  ensure type safety
         if (!(uniArray.get(0) instanceof University) || !(uniLinked.get(0) instanceof University)) {
             throw new ClassCastException("Both lists must contain elements of type University.");
         }

             ArrayList<University> uniArrayList = (ArrayList<University>) uniArray;
             LinkedList<University> uniLinkedList = (LinkedList<University>) uniLinked;
      
             
             int algo;
             int datastructure;
             Scanner input = new Scanner(System.in);

             
           
            
            boolean cont=false;
                do{
                System.out.println("Choose a data structure to use:");
                System.out.println("1. ArrayList");
                System.out.println("2. LinkedList");
                datastructure = input.nextInt();
                
                switch(datastructure){
                    case 1:

                      MergeSort.sort(uniArrayList);
                      cont=false;
                      break;
                    case 2:
                      MergeSort.sort(uniLinkedList);
                      cont=false;
                      break;
                    default: System.out.println("Not a valid choice"); 
                    cont=true;
                  }
                }while(cont);
                
            boolean conti=true;
          
            do{
               System.out.println("Choose a sorting algorithm to use:");
               System.out.println("1. BubbleSort");
               System.out.println("2. BuiltInSort");
               System.out.println("3. InsertionSort");
               System.out.println("4. MergeSort");     
               algo=input.nextInt();
               
               switch(algo){
                    case 1:
                       if(datastructure==1){
                           BubbleSort.sort(uniArrayList);   
                        }
                        else{
                           BubbleSort.sort(uniLinkedList);
                        }
                        conti=false;
                        break;

                    case 2:
                       if(datastructure==1){
                         BuiltInSort.sort(uniArrayList); 
                        }
                        else{
                            BuiltInSort.sort(uniLinkedList);
                        }       
                        conti=false;
                       break;

                    case 3:
                       if(datastructure==1){
                            InsertionSort.sort(uniArrayList);   
                       }
                       else{
                            InsertionSort.sort(uniLinkedList);
                       }
                       conti=false;
                       break;  
                    case 4:
                        if(datastructure==1){
                            MergeSort.sort(uniArrayList);
                        }
                        else{     
                            MergeSort.sort(uniLinkedList);
                        }
                            conti=false;
                             break;
                    default: System.out.println("Not a valid choice");       
             }
            } while(conti);
             
             if(datastructure==1){
                         printList(uniArrayList);
                     }
                     else{
                         printList(uniLinkedList);
                     }    
                   
                }
}