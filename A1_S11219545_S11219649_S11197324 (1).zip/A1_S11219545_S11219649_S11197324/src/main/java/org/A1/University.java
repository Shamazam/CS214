package org.A1;

import java.util.Comparator;
import java.util.function.Function;

public class University implements Comparable<University>{
    private int UniversityRank;
    private String NameofUniversity;
    private String Location;
    private int NoofStudent;
    private double NoofStudentperStaff;
    private String InternationalStudent;
    private String FemaleMaleRatio;
    private double OverAllScore;
    private double TeachingScore;
    private double ResearchScore;
    private double CitationsScore;
    private double IndustryIncomeScore;
    private double InternationalOutlookScore;

    @Override
    public int compareTo(University other) {
        // Default comparison based on UniversityRank
        return Integer.compare(this.UniversityRank, other.UniversityRank);
    }
    public static <T extends Comparable<T>> Comparator<University> compareBy(Function<University, T> keyExtractor, boolean ascending) {
        Comparator<University> comparator = Comparator.comparing(keyExtractor);
        return ascending ? comparator : comparator.reversed();
    }

    public double getCitationsScore() {
        return CitationsScore;
    }

    public double getIndustryIncomeScore() {
        return IndustryIncomeScore;
    }

    public double getInternationalOutlookScore() {
        return InternationalOutlookScore;
    }

    public double getNoofStudentperStaff() {
        return NoofStudentperStaff;
    }

    public double getOverAllScore() {
        return OverAllScore;
    }

    public double getResearchScore() {
        return ResearchScore;
    }

    public int getUniversityRank() {
        return UniversityRank;
    }

    public double getTeachingScore() {
        return TeachingScore;
    }

    public int getNoofStudent() {
        return NoofStudent;
    }

    public String getFemaleMaleRatio() {
        return FemaleMaleRatio;
    }

    public String getNameofUniversity() {
        return NameofUniversity;
    }

    public String getInternationalStudent() {
        return InternationalStudent;
    }

    public String getLocation() {
        return Location;
    }

    public void setCitationsScore(double citationsScore) {
        CitationsScore = citationsScore;
    }

    public void setFemaleMaleRatio(String femaleMaleRatio) {
        FemaleMaleRatio = femaleMaleRatio;
    }

    public void setIndustryIncomeScore(double industryIncomeScore) {
        IndustryIncomeScore = industryIncomeScore;
    }

    public void setInternationalOutlookScore(double internationalOutlookScore) {
        InternationalOutlookScore = internationalOutlookScore;
    }

    public void setNameofUniversity(String nameofUniversity) {
        NameofUniversity = nameofUniversity;
    }

    public void setInternationalStudent(String internationalStudent) {
        InternationalStudent = internationalStudent;
    }

    public void setLocation(String location) {
        Location = location;
    }

    public void setNoofStudent(int noofStudent) {
        NoofStudent = noofStudent;
    }

    public void setNoofStudentperStaff(double noofStudentperStaff) {
        NoofStudentperStaff = noofStudentperStaff;
    }

    public void setOverAllScore(double overAllScore) {
        OverAllScore = overAllScore;
    }

    public void setUniversityRank(String universityRank) {
        UniversityRank = Integer.parseInt(universityRank);
    }

    public void setResearchScore(double researchScore) {
        ResearchScore = researchScore;
    }

    public void setTeachingScore(double teachingScore) {
        TeachingScore = teachingScore;
    }
    
@Override
public String toString() {
      return String.format(
       "%-40s %-90s %-50s %-50s %-50s %-50s %-50s %-50s %-50s %-50s %-50s %-50s %-50s%n",
        "University Rank: " + UniversityRank,
        "Name of University: '" + NameofUniversity + '\'',
        "Location: '" + Location + '\'',
        "Number of Students: " + NoofStudent,
        "Number of Student per Staff: " + NoofStudentperStaff,
        "International Students: '" + InternationalStudent + '\'',
        "Female-Male Ratio: '" + FemaleMaleRatio + '\'',
        "OverAll Score: " + OverAllScore,
        "Teaching Score: " + TeachingScore,
        "Research Score: " + ResearchScore,
        "Citations Score: " + CitationsScore,
        "Industry IncomeScore: " + IndustryIncomeScore,
        "International OutlookScore: " + InternationalOutlookScore
        );

    }

}
