/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package org.A1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import static org.A1.Calculations.getMean;
import static org.A1.Calculations.getMedian;


/**
 *
 * @author c3rea
 */
public class DataInput {
    public  static void readFile(List universityList){         
    try { String file = "src\\World University Rankings 2023-Cleaned.csv";
    BufferedReader reader = null;
    String line = "";
    try {
        reader = new BufferedReader(new FileReader(file));
    } catch (FileNotFoundException ex) {
        Logger.getLogger(DataInput.class.getName()).log(Level.SEVERE, null, ex);
    }
    DiscardLine(reader); // Discard the header line
    
    String[] row;
    
    try {
        while ((line = reader.readLine()) != null) {
            row = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)"); // Split by commas but preserve quoted strings
            
            // Clean and format data appropriately
            String universityRank = row[0].trim();
            String nameOfUniversity = row[1].replaceAll("\"", "").trim(); // Remove quotes
            String location = row[2].trim();
            int noOfStudent = Integer.parseInt(row[3].replaceAll("[^\\d]", "")); // Remove commas and parse
            double noOfStudentPerStaff = parseDoubleWithRange(row[4].trim()); // Handle ranges
            String internationalStudent = row[5].replaceAll("%", "").trim(); // Remove percentage sign
            String femaleMaleRatio = row[6].replaceAll(":", ": ").trim(); // Format ratio properly
            double overallScore = parseDoubleWithRange(row[7].trim()); // Handle ranges
            double teachingScore = parseDoubleWithRange(row[8].trim()); // Handle ranges
            double researchScore = parseDoubleWithRange(row[9].trim()); // Handle ranges
            double citationsScore = parseDoubleWithRange(row[10].trim()); // Handle ranges
            double industryIncomeScore = parseDoubleWithRange(row[11].trim()); // Handle ranges
            double internationalOutlookScore = parseDoubleWithRange(row[12].trim()); // Handle ranges
            
            // Create a new University object and set its fields
            University uni = new University();
            uni.setUniversityRank(universityRank);
            uni.setNameofUniversity(nameOfUniversity);
            uni.setLocation(location);
            uni.setNoofStudent(noOfStudent);
            uni.setNoofStudentperStaff(noOfStudentPerStaff);
            uni.setInternationalStudent(internationalStudent);
            uni.setFemaleMaleRatio(femaleMaleRatio);
            uni.setOverAllScore(overallScore);
            uni.setTeachingScore(teachingScore);
            uni.setResearchScore(researchScore);
            uni.setCitationsScore(citationsScore);
            uni.setIndustryIncomeScore(industryIncomeScore);
            uni.setInternationalOutlookScore(internationalOutlookScore);
            
            // Add the university to the list
            universityList.add(uni);
      
            
            
        }
    } catch (Exception e) {
        e.printStackTrace();
    } finally {
        try {
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }} catch (IOException ex) {
            Logger.getLogger(DataInput.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    public static void DiscardLine(BufferedReader reader) throws IOException {
        reader.readLine(); // Skip the first line (header)
    }
    
     // Helper method to handle ranges
    public static double parseDoubleWithRange(String str) {
        // Handle the range
        if (str.contains("–")) { // Using en dash
            String[] parts = str.split("–");
            double first = Double.parseDouble(parts[0].trim());
            double second = Double.parseDouble(parts[1].trim());
            return (first + second) / 2; // Take the average
        } else if (str.contains("-")) { // Using hyphen
            String[] parts = str.split("-");
            double first = Double.parseDouble(parts[0].trim());
            double second = Double.parseDouble(parts[1].trim());
            return (first + second) / 2; // Take the average
        } else {
            // Single value
            return Double.parseDouble(str.trim());
        }
    }
    
    
    
 public static void readOperation(String filename,ArrayList<Integer>intArray) {
        BufferedReader bfr1 = null;

        try {
            bfr1 = new BufferedReader(new FileReader(filename));
            String line;
            while ((line = bfr1.readLine()) != null) {
                try {
                    // Parse the line into an integer and add it to the list
                    int number = Integer.parseInt(line.trim());
                    intArray.add(number);
                } catch (NumberFormatException e) {
                    // Handle the case where the line is not a valid integer
                    System.err.println("Invalid integer format: " + line);
                }
            }
        } catch (IOException ex) {
            // Handle file-related exceptions
            Logger.getLogger(Calculations.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (bfr1 != null) {
                try {
                    bfr1.close(); // Always close the BufferedReader
                } catch (IOException e) {
                    // Handle exceptions during close
                    Logger.getLogger(Calculations.class.getName()).log(Level.SEVERE, null, e);
                }
            }
        }     
    }   
    
    
}




